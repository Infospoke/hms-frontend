import {
  NZ_CONFIG,
  NzConfigService,
  WithConfig,
  getStyle,
  onConfigChangeEventForComponent,
  provideNzConfig,
  registerTheme,
  withConfigFactory
} from "./chunk-RFD3HE65.js";
import "./chunk-LS5YWOM7.js";
import "./chunk-6R3GHT4C.js";
import "./chunk-VG66SETI.js";
import "./chunk-PTDBFWNA.js";
import "./chunk-XYSLGILQ.js";
import "./chunk-KWSTWQNB.js";
export {
  NZ_CONFIG,
  NzConfigService,
  WithConfig,
  getStyle,
  onConfigChangeEventForComponent,
  provideNzConfig,
  registerTheme,
  withConfigFactory
};
