import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-3BCWT6NJ.js";
import "./chunk-72DKPDI6.js";
import "./chunk-BQ76GOFF.js";
import "./chunk-PIVALZLS.js";
import "./chunk-ANBN7I6Y.js";
import "./chunk-DDR7OREW.js";
import "./chunk-V2HEURKN.js";
import "./chunk-QVNYRLAE.js";
import "./chunk-RFD3HE65.js";
import "./chunk-LS5YWOM7.js";
import "./chunk-6R3GHT4C.js";
import "./chunk-VG66SETI.js";
import "./chunk-PTDBFWNA.js";
import "./chunk-XYSLGILQ.js";
import "./chunk-KWSTWQNB.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
