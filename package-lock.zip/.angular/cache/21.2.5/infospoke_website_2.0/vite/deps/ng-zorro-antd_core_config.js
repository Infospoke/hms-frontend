import {
  NZ_CONFIG,
  NzConfigService,
  WithConfig,
  getStyle,
  onConfigChangeEventForComponent,
  provideNzConfig,
  registerTheme,
  withConfigFactory
} from "./chunk-IUDP3MQ3.js";
import "./chunk-K4XQ25XI.js";
import "./chunk-GOYXSXUC.js";
import "./chunk-5NDX3Y6W.js";
import "./chunk-FSMCXCLM.js";
import "./chunk-UX5ZX4YQ.js";
import "./chunk-U4MHBQTI.js";
import "./chunk-XYSLGILQ.js";
import "./chunk-KWSTWQNB.js";
export {
  NZ_CONFIG,
  NzConfigService,
  WithConfig,
  getStyle,
  onConfigChangeEventForComponent,
  provideNzConfig,
  registerTheme,
  withConfigFactory
};
