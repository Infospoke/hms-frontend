import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-Y37XFCFQ.js";
import "./chunk-DLME7B56.js";
import "./chunk-UOH4B4VD.js";
import "./chunk-LJ7WFYCD.js";
import "./chunk-5NDX3Y6W.js";
import "./chunk-FSMCXCLM.js";
import "./chunk-UX5ZX4YQ.js";
import "./chunk-U4MHBQTI.js";
import "./chunk-XYSLGILQ.js";
import "./chunk-KWSTWQNB.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
