import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-S6TSDLJQ.js";
import "./chunk-72DKPDI6.js";
import "./chunk-DLME7B56.js";
import "./chunk-BQ76GOFF.js";
import "./chunk-IUDP3MQ3.js";
import "./chunk-K4XQ25XI.js";
import "./chunk-GOYXSXUC.js";
import "./chunk-JXLYNKO3.js";
import "./chunk-D3D2C3BC.js";
import "./chunk-UOH4B4VD.js";
import "./chunk-TAQF7Q6A.js";
import "./chunk-LJ7WFYCD.js";
import "./chunk-5NDX3Y6W.js";
import "./chunk-FSMCXCLM.js";
import "./chunk-UX5ZX4YQ.js";
import "./chunk-U4MHBQTI.js";
import "./chunk-XYSLGILQ.js";
import "./chunk-KWSTWQNB.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
