import {
  NZ_CONFIG,
  NzConfigService,
  WithConfig,
  getStyle,
  onConfigChangeEventForComponent,
  provideNzConfig,
  registerTheme,
  withConfigFactory
} from "./chunk-3CTDOXES.js";
import "./chunk-S5UPE26V.js";
import "./chunk-MSD5NR4X.js";
import "./chunk-PTDBFWNA.js";
import "./chunk-XYSLGILQ.js";
import "./chunk-H2SRQSE4.js";
export {
  NZ_CONFIG,
  NzConfigService,
  WithConfig,
  getStyle,
  onConfigChangeEventForComponent,
  provideNzConfig,
  registerTheme,
  withConfigFactory
};
