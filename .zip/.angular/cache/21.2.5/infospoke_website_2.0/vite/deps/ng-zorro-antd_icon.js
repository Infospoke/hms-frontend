import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-OVMRNB2Q.js";
import "./chunk-72DKPDI6.js";
import "./chunk-BQ76GOFF.js";
import "./chunk-CADM4U7A.js";
import "./chunk-NEANL7II.js";
import "./chunk-67RFN4CY.js";
import "./chunk-3CTDOXES.js";
import "./chunk-S5UPE26V.js";
import "./chunk-725JTSPS.js";
import "./chunk-ZJ7VULP6.js";
import "./chunk-MSD5NR4X.js";
import "./chunk-PTDBFWNA.js";
import "./chunk-XYSLGILQ.js";
import "./chunk-H2SRQSE4.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
