import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-4EMOFWDE.js";
import "./chunk-5NDX3Y6W.js";
import "./chunk-FSMCXCLM.js";
import "./chunk-UX5ZX4YQ.js";
import "./chunk-U4MHBQTI.js";
import "./chunk-XYSLGILQ.js";
import "./chunk-KWSTWQNB.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
